package com.example.touzouzadnaneatelier3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.util.List;
public class Activity2 extends AppCompatActivity {
    TextView namerecup,familyrecap;
    String prenom , nom;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        familyrecap=findViewById(R.id.familyrecap);
        namerecup=findViewById(R.id.namerecup);DataBase database = new DataBase(Activity2.this);

        database.getReadableDatabase();

        List<Informations> persons = database.ReccupInfos();

        for(Informations person: persons){
            nom = person.getFamilyname().toUpperCase();
            prenom = person.getFirstname().toUpperCase();
        }

        namerecup.setText(prenom);
        familyrecap.setText(nom);
    }
}