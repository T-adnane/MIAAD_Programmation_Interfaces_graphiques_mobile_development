package com.example.touzouzadnaneatelier3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DataBase extends SQLiteOpenHelper{
    public static final String DB_NAME = "atelier3";
    public static final int DB_VERSION = 1;
    //infos table livres
    public static final String TB_NAME = "informations";
    public static final String CL_ID = "id";
    public static final String CL_NAME = "first_name";
    public static final String CL_FAMILY = "family_name";
    public DataBase(Context c) {
        super(c, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + TB_NAME + " (" + CL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + CL_NAME + " TEXT, " + CL_FAMILY + " TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
    public Boolean ajouter(Informations inf) {
        //ajouter un nouvel enregistrement à partir de l'objet l
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put(CL_FAMILY, inf.getFamilyname());
        v.put(CL_NAME, inf.getFirstname());
        //v.put(CL_ID, inf.getId());
        if (db.insert(TB_NAME, null, v) == -1)
            return false;
        else return true;
    }
    public ArrayList<Informations> ReccupInfos() {
        ArrayList<Informations> lise = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor curseur = db.rawQuery("Select * FROM " + TB_NAME, null);
        if (curseur != null) {
            while (curseur.moveToNext()) {
                int id = curseur.getInt(0);
                String familyname = curseur.getString(1);
                String firstname = curseur.getString(2);
                Informations inf= new Informations(familyname,firstname);
                lise.add(inf);
            }
        }
        return lise;
    }
}