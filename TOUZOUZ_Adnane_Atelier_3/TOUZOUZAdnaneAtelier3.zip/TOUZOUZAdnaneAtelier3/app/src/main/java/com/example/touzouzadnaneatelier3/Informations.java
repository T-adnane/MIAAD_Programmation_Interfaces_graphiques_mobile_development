package com.example.touzouzadnaneatelier3;

public class Informations {
    private int id;
    private String familyname;
    private String firstname;

    public Informations(int id, String familyname, String firstname) {
        this.id = id;
        this.familyname = familyname;
        this.firstname = firstname;
    }
    public Informations(String familyname, String firstname) {
        this.familyname = familyname;
        this.firstname = firstname;
    }

    public int getId() {
        return id;
    }

    public String getFamilyname() {
        return familyname;
    }

    public String getFirstname() {
        return firstname;
    }
}
