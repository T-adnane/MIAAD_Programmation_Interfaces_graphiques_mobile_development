package com.example.touzouzadnaneatelier3;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText familyname, firstname;
    DataBase db;
    Button send;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        familyname=findViewById(R.id.familyname);
        firstname=findViewById(R.id.firstname);
        send=findViewById(R.id.send);
        db=new DataBase(this);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //lecture des EditTexts
                String family=familyname.getText().toString();
                String first=firstname.getText().toString();
                //création de l'objet à partir des éléments saisis
                Informations innff=new Informations (family,first);
                //inserer le nouvel enregistrement à partir de l'objet crée
                if(db.ajouter(innff)){
                    Toast.makeText(MainActivity.this,"Ajout avec succes!", Toast.LENGTH_SHORT).show();
                    Intent intent= new Intent(MainActivity.this, Activity2.class);
                    startActivity(intent);
                }
                else Toast.makeText(MainActivity.this,"Erreur!", Toast.LENGTH_SHORT).show();
            }
        });

    }
}